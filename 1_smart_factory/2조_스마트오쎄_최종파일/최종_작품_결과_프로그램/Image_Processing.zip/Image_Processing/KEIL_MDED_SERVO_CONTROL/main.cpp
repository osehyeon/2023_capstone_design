#include "mbed.h"
#include <stdio.h>
#include <stdlib.h>

Serial pc(USBTX, USBRX);    

PwmOut bottom(PB_10); // D5
PwmOut arm1(PB_4); // D6
PwmOut arm2(PA_9); // D8
PwmOut grip(PC_7); // D9
 
 

int main() {
    pc.baud(9600);
		

    char data;

	
		float servoMin = 0.03;
		float servoMax = 0.04;
		float servoMin1 = 0.04;
		float servoMax1 = 0.08;
		float servoMin2 = 0.03;
		float servoMax2 = 0.6;
		float servoMin3 = 0.05;
		float servoMax3 = 0.1;
	
		float servo1 = 0.04; 
		float servo2 = (servoMax1 + servoMin1)/2;
	  float servo3 = (servoMax2 + servoMin2)/2;
	  float servo4 = (servoMax3 + servoMin3)/2;
	
		grip = servo1;
		arm1  = servo2;
		arm2  = servo3;
		bottom  = servo4;
		

       while (1) {
        if (pc.readable()) {
            char data = pc.getc(); 
				
            if (data == 'g') {
                servo1 = 0.025;  //0.025~0.125 = 20~160 degree
							  grip = servo1;

								wait_ms(100);
							
            } else if (data == 'r') {
                servo1 = 0.04;
								grip = servo1;							
              
							  wait_ms(50);
							
            } else if (data == 'a') {
							for (int i = 0; i < 5; i++){
								servo2 = servo2 + 0.001;
								wait_ms(100);
								
								if (servo2 > servoMax1) {
								servo2 = servoMax1;
								}
								else if (servo2 < servoMin1) {
								servo2 = servoMin1;
								}
								
								arm1  = servo2;
								
							}
							
						}
						  else if (data == 'b') {
								for (int j = 0; j < 5; j++){
								servo2 = servo2 - 0.001;
								wait_ms(100);
								
								if (servo2 > servoMax) {
								servo2 = servoMax;
								}
								else if (servo2 < servoMin) {
								servo2 = servoMin;
								}
								
								arm1  = servo2;
								
								}
								
						}
							
							else if (data == 'f') {
							for (int i = 0; i < 5; i++){
								servo3 = servo3 + 0.001;
								wait_ms(50);
								
								if (servo3 > servoMax2) {
								servo3 = servoMax;
								}
								else if (servo3 < servoMin2) {
								servo3 = servoMin;
								}
								
								//arm2  = servo3;
								
							}
						
						}
						  else if (data == 'e') {
								for (int j = 0; j < 5; j++){
								servo3 = servo3 - 0.001;
								wait_ms(100);
								
								if (servo3 > servoMax2) {
								servo3 = servoMax;
								}
								else if (servo3 < servoMin2) {
								servo3 = servoMin;
								}
								
								//arm2  = servo3;
								
								}
			
						}
							
							else if (data == 'c') {
							for (int i = 0; i < 5; i++){
								servo4 = servo4 + 0.003;
								wait_ms(100);
								if (servo4 > servoMax3) {
								servo4 = servoMax3;
								}
								else if (servo4 < servoMin3) {
								servo4 = servoMin3;
								}
								
								bottom  = servo4;
								
							}
							  
						}
						  else if (data == 'd') {
								for (int j = 0; j < 5; j++){
								servo4 = servo4 - 0.003;
								wait_ms(100);
								
								if (servo4 > servoMax3) {
								servo4 = servoMax3;
								}
								else if (servo4 < servoMin3) {
								servo4 = servoMin3;
								}
								
								bottom  = servo4;
								
								}
						
						}
						

						
						
					
        }
    
    }
		
}
