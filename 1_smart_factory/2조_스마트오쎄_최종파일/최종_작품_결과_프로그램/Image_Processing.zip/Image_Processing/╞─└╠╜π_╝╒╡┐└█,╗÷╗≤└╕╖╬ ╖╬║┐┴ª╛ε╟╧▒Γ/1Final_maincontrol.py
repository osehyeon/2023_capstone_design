import cv2 as cv #opencv 라이브러리 설치 및 cv로 이름변경
import mediapipe as mp
import numpy as np
import serial

#PYTHON 3.8 버전에서 작업함
#opencv, mediapipe, numpy, pyserial  각각 라이브러리 설치/ pip install
#https://github.com/kairess/Rock-Paper-Scissors-Machine
#위 링크의 data폴더를 프로젝트 안에 넣어줬음/ data폴더는 동작학습파일

ser = serial.Serial('COM4', 9600)
id = -1 #무입력
data1 = 'g'#'grip'
data2 = 'r'#'release'
data11 = data1.encode() #시리얼코드에 작성하기 위해서 엔코드과정
data22 = data2.encode()

data3 = 'a'
data4 = 'b'
data33 = data3.encode() #시리얼코드에 작성하기 위해서 엔코드과정
data44 = data4.encode()

data5 = 'c'
data6 = 'd'
data55 = data5.encode() #시리얼코드에 작성하기 위해서 엔코드과정
data66 = data6.encode()

data7 = 'e'
data8 = 'f'
data77 = data7.encode() #시리얼코드에 작성하기 위해서 엔코드과정
data88 = data8.encode()



flag1 = 0
flag2 = 0

previous_wx = 0
previous_wy = 0
previous_center_x = 0
previous_center_y = 0

wx = 0
wy = 0
center_x = 0
center_y = 0

diff_wx = 0
diff_wy = 0
diff_center_x = 0
diff_center_y = 0

#손모양을 인식하는 코드
max_num_hands = 1
gesture = {
    0:'fist', 5:'five'
}
# 그외 가능한것들 1:'one', 2:'two', 3:'three', 4:'four', 6:'six', 7:'rock', 8:'spiderman', 9:'yeah', 10:'ok'

rps_gesture = {0:'Grip', 5:'Release'} #위와 같이 다양한 인식이 가능, 0번과 5번을 잡기,놓기로 설정

# MediaPipe hands model
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(
    max_num_hands=max_num_hands,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5)

# Gesture recognition model
file = np.genfromtxt('data/gesture_train.csv', delimiter=',')
angle = file[:,:-1].astype(np.float32)
label = file[:, -1].astype(np.float32)
knn = cv.ml.KNearest_create()
knn.train(angle, cv.ml.ROW_SAMPLE, label)

state = None


cap = cv.VideoCapture(0)
# 비디오 크기 조절
#cap.set(cv.CAP_PROP_FRAME_WIDTH, 640)
#cap.set(cv.CAP_PROP_FRAME_HEIGHT, 480)

# 프레임 속도 조절
cap.set(cv.CAP_PROP_FPS, 20)
while cap.isOpened():

    ret, img_color = cap.read()

    img_color = cv.flip(img_color, 1)

    img_hsv = cv.cvtColor(img_color, cv.COLOR_BGR2HSV) #색상인식을 위한 hsv영역 이미지준비

    if not ret:
        continue

    img_color = cv.cvtColor(img_color, cv.COLOR_BGR2RGB)

    result = hands.process(img_color) #RGB 환경의 hand함수 이미지인식

    img_color = cv.cvtColor(img_color, cv.COLOR_RGB2BGR) #opencv 환경에 맞추어 BGR로 재변환

    if result.multi_hand_landmarks is not None:
        for res in result.multi_hand_landmarks:
            joint = np.zeros((21, 3))
            for j, lm in enumerate(res.landmark):
                joint[j] = [lm.x, lm.y, lm.z]

            # Compute angles between joints
            v1 = joint[[0,1,2,3,0,5,6,7,0,9,10,11,0,13,14,15,0,17,18,19],:] # Parent joint
            v2 = joint[[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],:] # Child joint
            v = v2 - v1 # [20,3]
            # Normalize v
            v = v / np.linalg.norm(v, axis=1)[:, np.newaxis]

            # Get angle using arcos of dot product
            angle = np.arccos(np.einsum('nt,nt->n',
                v[[0,1,2,4,5,6,8,9,10,12,13,14,16,17,18],:],
                v[[1,2,3,5,6,7,9,10,11,13,14,15,17,18,19],:])) # [15,]

            angle = np.degrees(angle) # Convert radian to degree


            # Inference gesture
            data = np.array([angle], dtype=np.float32)
            ret, results, neighbours, dist = knn.findNearest(data, 3)
            idx = int(results[0][0])




            # Draw gesture result
            if idx in rps_gesture.keys():
                cv.putText(img_color, text=rps_gesture[idx].upper(), org=(int(res.landmark[0].x * img_color.shape[1]), int(res.landmark[0].y * img_color.shape[0] + 20)), fontFace=cv.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(255, 255, 255), thickness=2)

                state = rps_gesture[idx] #현재 그립상태를 출력하기 위한 변수




                if state == "Grip":
                    id = 0 #잡기

                    ser.write(data11)
                    if flag1 == 0: 

                        flag1 = 1
                        flag2 = 0    
                elif state == "Release":
                    id = 1 #놓기

                    ser.write(data22)
                    if flag2 == 0:

                        flag2 = 1
                        flag1 = 0
            # Other gestures
            # cv2.putText(img, text=gesture[idx].upper(), org=(int(res.landmark[0].x * img.shape[1]), int(res.landmark[0].y * img.shape[0] + 20)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(255, 255, 255), thickness=2)

            mp_drawing.draw_landmarks(img_color, res, mp_hands.HAND_CONNECTIONS)



        wx = joint[0][0] * 1000  # 왼쪽으로 3자리 이동 (10의 제곱)
        wy = joint[0][1] * 1000
        #wz = joint[0][2] * 1000

        #print("wrist_x: {:.0f}".format(wx),
              #"wrist_y: {:.0f}".format(wy),"   Command:",state,"ID:", id , "g", data11, "ri", data22)  # "z: {:.0f}".format(joint[0][2])) z값도 있긴한데 대부분 0 출력으로 필요없을듯

        #print("wirst_x: {:.3f}".format(joint[0][0]), "wrist_y: {:.3f}".format(joint[0][1])) # "z: {:.3f}".format(joint[0][2])) 자릿수 이동하지 않은 순수 print문



    #여기 아래서부터 색상을 인식하는 코드
    hue_blue = 120  # 색상 파란색
    lower_blue = (hue_blue - 10, 220, 220)# 최소범위 색상값
    upper_blue = (hue_blue + 10, 255, 255)  # 최대범위 색상값
    img_mask = cv.inRange(img_hsv, lower_blue, upper_blue)



    kernel = cv.getStructuringElement(cv.MORPH_RECT, (5, 5))
    img_mask = cv.morphologyEx(img_mask, cv.MORPH_DILATE, kernel, iterations=5)




    nlabels, labels, stats, centroids = cv.connectedComponentsWithStats(img_mask)

    max = -1
    max_index = -1


    for i in range(nlabels):

        if i < 1:
            continue

        area = stats[i, cv.CC_STAT_AREA]


        if area > max:
            max = area

            max_index = i

    if max_index != -1:
        center_x = int(centroids[max_index, 0])
        center_y = int(centroids[max_index, 1])
        left = stats[max_index, cv.CC_STAT_LEFT]
        top = stats[max_index, cv.CC_STAT_TOP]
        width = stats[max_index, cv.CC_STAT_WIDTH]
        height = stats[max_index, cv.CC_STAT_HEIGHT]

        #좌표값 print출력
        #print("color_x:", center_x, "color_y:", center_y)

        cv.rectangle(img_color, (left, top), (left + width, top + height), (0, 0, 255), 5)
        cv.circle(img_color, (center_x, center_y), 10, (0, 255, 0), -1)

        # 이미지 출력
    cv.imshow('Result', img_color)

    #cv.imshow('mask',img_mask) #마스크된 영역을 확인가능

    # wx,wy,center_y 좌표값 차이계산
    diff_wx = wx - previous_wx
    diff_wy = wy - previous_wy
    diff_center_x = center_x - previous_center_x

    #정수형으로 변환하여 소수점 버림
    diff_wx = int(diff_wx)
    diff_wy = int(diff_wy)
    diff_center_x = int(50* diff_center_x)

    # 차이 값을 저장
    previous_wx = wx
    previous_wy = wy
    previous_center_x = center_x


    d_down =-10;
    d_up = 10;


    if diff_wx >= d_up:
        ser.write(data33)
    elif diff_wx <= d_down:
        ser.write(data44)

    if diff_wy >= d_up:
        ser.write(data55)
    elif diff_wy <= d_down:
        ser.write(data66)

    if diff_center_x >= 200:
        ser.write(data77)
    elif diff_center_x <= -200:
        ser.write(data88)

    # 좌표값 변화량 확인
    print("Difference in wx:", diff_wx, "Difference in wy:", diff_wy, "Difference in center_x:", diff_center_x)




    if cv.waitKey(1) == 27:  # ord('q')를 넣으면 q를 누를때 종료, ord() 함수는 문자의 유니코드 코드 포인트 값을 반환/ esc = 27
            cap.release() #카메라 닫기
            cv.destroyAllWindows() #윈도우 리소스 제거
            ser.close() #시리얼 닫기
            break