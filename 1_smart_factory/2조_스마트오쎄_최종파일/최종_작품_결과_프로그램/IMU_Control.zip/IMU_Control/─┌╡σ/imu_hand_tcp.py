import socket
import serial
import time

import cv2 as cv #opencv 라이브러리 설치 및 cv로 이름변경
import mediapipe as mp #터미널에서 pip install mediapipe 설치했음 / data폴더를 프로젝트 안에 넣어줬음
import numpy as np

data1 = 'grip'
data2 = 'release'
data1 = data1.encode()
data2 = data2.encode()
flag1 = 0
flag2 = 0

#손모양을 인식하는 코드
max_num_hands = 1
gesture = {
    0:'fist', 5:'five'
}

rps_gesture = {0:'Grip', 5:'Release'}

# MediaPipe hands model
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(
    max_num_hands=max_num_hands,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5)

# Gesture recognition model
file = np.genfromtxt('gesture_train.csv', delimiter=',')
angle = file[:,:-1].astype(np.float32)
label = file[:, -1].astype(np.float32)
knn = cv.ml.KNearest_create()
knn.train(angle, cv.ml.ROW_SAMPLE, label)
state = None
cap = cv.VideoCapture(0)
cap.set(cv.CAP_PROP_FOURCC, cv.VideoWriter_fourcc('M', 'J', 'P', 'G'))
cap.set(cv.CAP_PROP_FPS, 20)

#imu sensor data definition
current_yaw = 0.0
prev_yaw = 0.0
rotate = 0.0
count = 0

threshold = 100.0
flag = 0;

threshold1 = -100.0
flag0 = 0;

prev_gyro_x = 0
current_gyro_x = 0
peak_gyro_x = []
peak_gyro_x_average = 0

# IMU 센서와의 시리얼 통신 설정
ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)  # 아두이노가 연결된 포트와 통신 속도 설정. 포트는 실제 연결된 포트로 변경해야 함.
line = ser.readline().decode('utf-8').strip()  # 시리얼 통신으로 들어온 데이터 읽기
current_yaw = float(line.split()[8])
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect(('192.168.0.10', 9008))     # 접속할 서버의 IP주소와 포트번호 입력.

#arduino set up
ser1 = serial.Serial('/dev/ttyUSB1', 9600)

try:
    while True:
        # while cap.isOpened():
        line = ser.readline().decode('utf-8').strip()  # 시리얼 통신으로 들어온 데이터 읽기
        imu_data = line.split()  # 데이터를 공백으로 구분하여 분리
        count += 1

        prev_gyro_x = current_gyro_x
        current_gyro_x = float(imu_data[3])

        if (current_gyro_x >= threshold):
            if ((prev_gyro_x >= current_gyro_x) and (flag == 0)):
                peak_gyro_x.append(prev_gyro_x)
                flag = 1
                sock.send(('up' + '\n').encode())  # 읽은 데이터를 소켓을 통해 전송
                message = 'up'
                ser1.write(message.encode())
                time.sleep(0.1)  # 필요에 따라 대기. 너무 빠른 전송을 방지하기 위함.

        if (current_gyro_x < threshold):
            flag = 0

        if (current_gyro_x <= threshold1):
            if ((prev_gyro_x <= current_gyro_x) and (flag0 == 0)):
                peak_gyro_x.append(prev_gyro_x)
                flag0 = 1
                sock.send(('down' + '\n').encode())  # 읽은 데이터를 소켓을 통해 전송
                message = 'down'
                ser1.write(message.encode())
                time.sleep(0.1)  # 필요에 따라 대기. 너무 빠른 전송을 방지하기 위함.

        if (current_gyro_x > threshold1):
            flag0 = 0

        if count == 12:
            prev_yaw = current_yaw
            current_yaw = float(imu_data[8])
            rotate = current_yaw - prev_yaw

            if (rotate > 180): rotate -= 360
            if (rotate < -180): rotate += 360

            print("current_yaw = {}".format(current_yaw))
            print("rotate = {}".format(rotate))

            if rotate >= 80:
                sock.send(('left' + '\n').encode())  # 읽은 데이터를 소켓을 통해 전송
                message = 'left'
                ser1.write(message.encode())
                time.sleep(0.1)  # 필요에 따라 대기. 너무 빠른 전송을 방지하기 위함.

            if rotate <= -80:
                sock.send(('right' + '\n').encode())  # 읽은 데이터를 소켓을 통해 전송
                message = 'right'
                ser1.write(message.encode())
                time.sleep(0.1)  # 필요에 따라 대기. 너무 빠른 전송을 방지하기 위함.
            count = 0

        if ser.in_waiting > 0:
            line = ser.readline().decode('utf-8').rstrip()  # 시리얼 포트에서 한 줄 읽기
            sock.send((line + '\n').encode())  # 읽은 데이터를 소켓을 통해 전송
            time.sleep(0.1)  # 필요에 따라 대기. 너무 빠른 전송을 방지하기 위함.


        ret, img_color = cap.read()

        img_color = cv.flip(img_color, 1)

        img_hsv = cv.cvtColor(img_color, cv.COLOR_BGR2HSV)  # 색상인식을 위한 hsv영역 이미지준비

        if not ret:
            continue

        img_color = cv.cvtColor(img_color, cv.COLOR_BGR2RGB)

        result = hands.process(img_color)  # RGB 환경의 hand함수 이미지인식

        img_color = cv.cvtColor(img_color, cv.COLOR_RGB2BGR)  # opencv 환경에 맞추어 BGR로 재변환

        if result.multi_hand_landmarks is not None:
            for res in result.multi_hand_landmarks:
                joint = np.zeros((21, 3))
                for j, lm in enumerate(res.landmark):
                    joint[j] = [lm.x, lm.y, lm.z]

                # Compute angles between joints
                v1 = joint[[0, 1, 2, 3, 0, 5, 6, 7, 0, 9, 10, 11, 0, 13, 14, 15, 0, 17, 18, 19], :]  # Parent joint
                v2 = joint[[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
                     :]  # Child joint
                v = v2 - v1  # [20,3]
                # Normalize v
                v = v / np.linalg.norm(v, axis=1)[:, np.newaxis]

                # Get angle using arcos of dot product
                angle = np.arccos(np.einsum('nt,nt->n',
                                            v[[0, 1, 2, 4, 5, 6, 8, 9, 10, 12, 13, 14, 16, 17, 18], :],
                                            v[[1, 2, 3, 5, 6, 7, 9, 10, 11, 13, 14, 15, 17, 18, 19], :]))  # [15,]

                angle = np.degrees(angle)  # Convert radian to degree

                # Inference gesture
                data = np.array([angle], dtype=np.float32)
                ret, results, neighbours, dist = knn.findNearest(data, 3)
                idx = int(results[0][0])

                # Draw gesture result
                if idx in rps_gesture.keys():
                    cv.putText(img_color, text=rps_gesture[idx].upper(), org=(
                    int(res.landmark[0].x * img_color.shape[1]), int(res.landmark[0].y * img_color.shape[0] + 20)),
                               fontFace=cv.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(255, 255, 255), thickness=2)

                    state = rps_gesture[idx]  # 현재 그립상태를 출력하기 위한 변수

                    id = -1  # 무입력

                    if state == "Grip":
                        id = 0  # 잡기
                        if flag1 == 0:
                            sock.send(('Grip' + '\n').encode())  # 읽은 데이터를 소켓을 통해 전송
                            time.sleep(0.1)
                            # ser.write(data1)
                            flag1 = 1
                            flag2 = 0
                    elif state == "Release":
                        id = 1  # 놓기
                        if flag2 == 0:
                            sock.send(('Release' + '\n').encode())  # 읽은 데이터를 소켓을 통해 전송
                            time.sleep(0.1)
                            # ser.write(data2)
                            flag2 = 1
                            flag1 = 0
                # Other gestures
                # cv2.putText(img, text=gesture[idx].upper(), org=(int(res.landmark[0].x * img.shape[1]), int(res.landmark[0].y * img.shape[0] + 20)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(255, 255, 255), thickness=2)

                mp_drawing.draw_landmarks(img_color, res, mp_hands.HAND_CONNECTIONS)

            wx = joint[0][0] * 1000  # 왼쪽으로 3자리 이동 (10의 제곱)
            wy = joint[0][1] * 1000
            # wz = joint[0][2] * 1000

            print("wrist_x: {:.0f}".format(wx),
                  "wrist_y: {:.0f}".format(wy), "   Command:", state, "ID:", id)

        cv.imshow('Result', img_color)

        if cv.waitKey(1) == 27:  # ord('q')를 넣으면 q를 누를때 종료, ord() 함수는 문자의 유니코드 코드 포인트 값을 반환/ esc = 27
            cap.release()
            cv.destroyAllWindows()
            break


except KeyboardInterrupt:
    ser.close()
    sock.close()


