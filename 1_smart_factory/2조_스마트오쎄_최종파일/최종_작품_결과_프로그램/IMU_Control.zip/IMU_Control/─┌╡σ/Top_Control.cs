using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO.Ports;
using System.Threading;
using System.Net.Sockets;
using System.Text;
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Net;


public class Top_Control : MonoBehaviour
{

    // 제어 변수 
    public float rotateSpeed = 30f; 
    public GameObject targetObject1; 
    public GameObject targetObject2; 
    public GameObject targetObject3; 
    public GameObject targetObject4; 
    
    float Rotation = 0.0f;

    private TcpListener _server;
    private TcpClient _client;
    private NetworkStream _stream;
    private byte[] _buffer;
    private Queue<string> _messages;

    //SerialPort m_SerialPort = new SerialPort("COM12", 9600, Parity.None, 8, StopBits.One); 

    private async void Start()
    {
        _messages = new Queue<string>();
        _buffer = new byte[1024];
        _server = new TcpListener(IPAddress.Parse("192.168.0.10"), 9008);
        _server.Start();

        _client = await _server.AcceptTcpClientAsync();
        _stream = _client.GetStream();

        Task.Run(async () =>
        {
            while (true)
            {
                if (_stream.DataAvailable)
                {
                    int bytesRead = await _stream.ReadAsync(_buffer, 0, _buffer.Length);
                    string message = Encoding.UTF8.GetString(_buffer, 0, bytesRead);
                    lock (_messages)
                    {
                        _messages.Enqueue(message);
                    }
                }
            }
        });
    }
    
    IEnumerator RotateObjectOverTime(GameObject obj, Vector3 totalRotation, float duration)
    {
        float elapsed = 0f;
        Vector3 initialRotation = obj.transform.eulerAngles;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            Vector3 currentRotation = Vector3.Lerp(initialRotation, initialRotation + totalRotation, elapsed / duration);
            obj.transform.eulerAngles = currentRotation;
            yield return null;
        }

        // Ensure the object has reached the exact target rotation
        obj.transform.eulerAngles = initialRotation + totalRotation;
    }

    private void Update()
    {
        if (_messages.Count > 0)
        {
            lock (_messages)
            {
                string message = _messages.Dequeue();
                Debug.Log($"Received data: {message}");

                if (message.Trim() == "up") // 위
                {
                    StartCoroutine(RotateObjectOverTime(targetObject2, new Vector3(0, 0, 50), 1f));
                }   
                if (message.Trim() == "down") // 아래
                {
                    StartCoroutine(RotateObjectOverTime(targetObject2, new Vector3(0, 0, -50), 1f));
                }

                if (message.Trim() == "left") //왼쪽
                {
                    StartCoroutine(RotateObjectOverTime(targetObject1, new Vector3(0, -90, 0), 1f));
                    //targetObject1.transform.Rotate(0, -90.0f, 0);

                }
                if (message.Trim() == "right") //오른쪽                        
                {
                    StartCoroutine(RotateObjectOverTime(targetObject1, new Vector3(0, 90, 0), 1f));
                    //targetObject1.transform.Rotate(0, 90.0f, 0);                  
                }
                //targetObject1.transform.Rotate(0, 90.0f, 0);
                if (message.Trim() == "Grip")
                {
                    StartCoroutine(RotateObjectOverTime(targetObject4, new Vector3(0, -50, 0), 1f));
                }

                if (message.Trim() == "Release")
                {
                    StartCoroutine(RotateObjectOverTime(targetObject4, new Vector3(0, 50, 0), 1f));
                }
      


                
            }
        }
    }


}
