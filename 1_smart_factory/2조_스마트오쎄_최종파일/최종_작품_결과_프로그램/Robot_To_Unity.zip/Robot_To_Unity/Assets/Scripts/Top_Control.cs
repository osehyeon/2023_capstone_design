using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO.Ports;
using System.Threading;

public class Top_Control : MonoBehaviour
{

    // 제어 변수 
    public float rotateSpeed = 30f; 
    public GameObject targetObject1; 
    public GameObject targetObject2; 
    public GameObject targetObject3; 
    public GameObject targetObject4; 
    
    float Rotation = 0.0f;

    SerialPort m_SerialPort = new SerialPort("COM12", 9600, Parity.None, 8, StopBits.One); 

    void Start()
    {
        m_SerialPort.Open(); 
    }
    void Update()
    {
        // 시리얼 통신 
        
        if (float.TryParse(m_SerialPort.ReadLine(), out Rotation)) {
            Debug.Log(Rotation); 
            if(Mathf.Abs(Rotation) == 1)
                targetObject1.transform.Rotate(new Vector3(0, -Rotation/1.0f, 0));
            if(Mathf.Abs(Rotation) == 11)
                targetObject2.transform.Rotate(new Vector3(0, 0, -Rotation/11.0f));
            if(Mathf.Abs(Rotation) == 21)
                targetObject3.transform.Rotate(new Vector3(0, 0, Rotation/21.0f));
            if(Mathf.Abs(Rotation) == 31)
                targetObject4.transform.Rotate(new Vector3(0, Rotation/31.0f, 0));
        }
        
        // 키보드 
        if (Input.GetKey(KeyCode.UpArrow))
            targetObject2.transform.Rotate(0, 0, -rotateSpeed * Time.deltaTime);
        if (Input.GetKey(KeyCode.DownArrow))
            targetObject2.transform.Rotate(0, 0, rotateSpeed * Time.deltaTime);
        if (Input.GetKey(KeyCode.LeftArrow))
            targetObject1.transform.Rotate(0, -rotateSpeed * Time.deltaTime, 0);
        if (Input.GetKey(KeyCode.RightArrow))
            targetObject1.transform.Rotate(0, rotateSpeed * Time.deltaTime, 0);
        
        if (Input.GetKey(KeyCode.W))
            targetObject3.transform.Rotate(0, 0, rotateSpeed * Time.deltaTime);
        if (Input.GetKey(KeyCode.S))
            targetObject3.transform.Rotate(0, 0, -rotateSpeed * Time.deltaTime);
        if (Input.GetKey(KeyCode.A))
            targetObject4.transform.Rotate(0, -rotateSpeed * Time.deltaTime, 0);
        if (Input.GetKey(KeyCode.D))
            targetObject4.transform.Rotate(0, rotateSpeed * Time.deltaTime, 0);

    }

}
